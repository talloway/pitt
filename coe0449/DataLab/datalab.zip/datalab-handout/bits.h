//1
int bitXor(int, int);
int test_bitXor(int, int);
int tmin();
int test_tmin();
//2
int allOddBits();
int test_allOddBits();
//3
int conditional(int, int, int);
int test_conditional(int, int, int);
//4
int logicalNeg(int);
int test_logicalNeg(int);
//float
int floatFloat2Int(unsigned);
int test_floatFloat2Int(unsigned);
