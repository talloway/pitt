#ifndef COMMON_H
#define COMMON_H

// Prevents compiler warning
int printf(const char *, ...);

// Prints the binary representation of integer x
void print_binary(int);

// Prints string representation of array x
void print_array(int *, int);

#endif
